exports.handler = async (event) => {
  console.log("🟢 PreSignUp triggered:");
  console.log("Received attributes:", JSON.stringify(event.request.userAttributes, null, 2));

  // You can modify event.request.userAttributes here if needed
  // For example: event.request.userAttributes["custom:user_type"] = "customer";

  // Allow user creation to proceed
  event.response = {
    autoConfirmUser: true,
    autoVerifyEmail: true
  };

  return event;
};